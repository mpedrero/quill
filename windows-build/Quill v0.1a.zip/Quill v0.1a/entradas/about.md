Aquí puedes escribir alguna información sobre tí, como tu nombre, a qué te dedicas, aficiones, etc. Incluso puedes añadir alguna foto. Esta entrada no necesita etiquetas de título, autor, etc. Ya que se establece automáticamente.

También puede ser interesante explicar la temática del blog, enlazar a alguna categoría interesante o a alguna de las entradas más destacadas.

No olvides incluir algunos métodos de contacto como tu [Twitter](www.twitter.com) o un <email.de.contacto@mail.com>